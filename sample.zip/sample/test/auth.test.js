const expect = require("chai").expect;
const request = require("supertest");
const server = require("../server");

const app = request.agent(server);

describe("POST request", () => {
	describe("creating a user", () => {
		it("should return access token if user doesn't exist", () => { });
		it("should return username exist", () => {
			// app
			//   .post("/api/auth/register")
			//   .send({
			//     first_name: "Emmanuel",
			//     last_name: "Bolatito",
			//     username: "Bolyjay2234",
			//     password: "Masmas124.",
			//   })
			//   .end((err, res) => {
			//     expect(res.status).to.equal(400);
			//     expect(res.body["error_msg"]).to.equal("Username already exists");
			//   });
		});
	});
});
