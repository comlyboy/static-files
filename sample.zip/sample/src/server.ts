import app from "./app";
const PORT = 1234;
app.listen(PORT, () => {
	console.log(`Server running on http://localhost:${PORT}`);
});
