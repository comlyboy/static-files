import express from "express";
import bcrypt from "bcryptjs";

import { IUser, LoginDto, RegisterDto } from "../model/user.interface";
import { User } from "../model/user.schema";
import { SignJWT, VerifyJWT } from "../util/jwt";
import { ConfirmatioMail, SignUpMail } from "../util/mail.templates";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, GetCommand, PutCommand } from "@aws-sdk/lib-dynamodb";
import { S3Client } from "@aws-sdk/client-s3";


export async function SignupUser(req: express.Request, res: express.Response, next: express.NextFunction) {

	try {
		const requestOrigin = req.headers.origin;

		const { firstName, surName, email, password }: RegisterDto = req.body;

		const user = await User.findOne({ email }).exec();
		if (user) {
			return res.status(401).json({
				message: "Email already registered!",
			});
		}

		// dynamo DB version
		await DynamoDbInstance().send(new GetCommand({
			TableName: 'dfddfgjrskdh',
			Key: { id: ' ' },
			ReturnConsumedCapacity: 'TOTAL'
		}))
		// ========

		const hashedPassword = await bcrypt.hash(password, 10);

		const token = await SignJWT({ email });

		const newUser = new User();
		newUser.firstName = firstName;
		newUser.surName = surName;
		newUser.email = email;
		newUser.registrationToken = token;
		newUser.password = hashedPassword;


		await DynamoDbInstance().send(new PutCommand({
			TableName: 'dfddfgjrskdh',
			Item: { id: Math.random(), ...req.body }
		}))


		const result = await newUser.save();
		if (!result) {
			return res.status(401).json({
				message: 'Registration not successfull!'
			});
		}

		const confirmURL = `${requestOrigin}/confirm/${result.registrationToken}`

		// const emailData = {
		//     to: result.email,
		//     subject: "Account verification instructions",
		//     html: SignUpMail(`${result.firstName} ${result.surName}`, confirmURL)
		// };

		res.status(201).json({
			message: 'Registered successfully!'
		});

	} catch (error) {
		res.status(500).json({
			message: error.message
		});
	}

}


export async function LoginUser(req: express.Request, res: express.Response, next: express.NextFunction) {
	try {
		const { email, password }: LoginDto = req.body;

		const user = await User.findOne({ email }).exec();
		if (!user) {
			return res.status(401).json({
				message: "Not a registered user!",
			});
		}

		if (!user.isVerified) {
			return res.status(401).json({
				message: 'User is not verified. Check email and retry',
				isSuccessful: false
			});
		}

		const hashResult = await bcrypt.compare(password, user.password);
		if (!hashResult) {
			return res.status(401).json({
				message: "Invalid username/password!",
			});
		}

		const token = await SignJWT({
			_id: user._id,
			isVerified: user.isVerified,
			email: user.email
		});

		res.status(200).json({
			// message: 'Welcome!!!',
			data: {
				token,
				user: {
					_id: user._id,
					firstName: user.firstName,
					surName: user.surName,
					email: user.email,
					isVerified: user.isVerified
				}
			},
		});

	} catch (error) {
		res.status(500).json({
			message: error.message,
		});
	}

}



export async function VerifyUser(req: express.Request, res: express.Response, next: express.NextFunction) {

	try {
		const registrationToken = req.params.registrationToken;

		const user = await User.findOne({ registrationToken }).exec();
		if (!user) {
			return res.status(401).json({
				message: 'Invalid verification code!',
			});
		}

		if (user.isVerified) {
			return res.status(401).json({
				message: 'User account already verified!',
			});
		}

		const { email } = await VerifyJWT(registrationToken) as IUser;

		const result = await User.updateOne(
			{ _id: user._id },
			{ $set: { isVerified: true } }
		);

		if (result.modifiedCount <= 0) {
			return res.status(400).json({
				message: 'Verification not successful!',
			});
		}

		const emailData = {
			to: user.email,
			subject: "Account verified successfully",
			html: ConfirmatioMail(`${user.firstName} ${user.surName}`)
		};

		res.status(200).json({
			message: 'User verification successful!',
		});

	} catch (error) {
		res.status(500).json({
			message: error.message,
		});
	}

}



function DynamoDbInstance(): DynamoDBDocumentClient {
	const dynamoClient = new DynamoDBClient({
		region: 'us-east-1',
		credentials: {
			accessKeyId: 'dkfjgrhjska',
			secretAccessKey: 'dfjgjshkakdfjbd'
		}
	});
	return DynamoDBDocumentClient.from(dynamoClient, this.translateConfig);
}

function s3Instance(): S3Client {
	return new S3Client({
		region: 'us-east-1',
		credentials: {
			accessKeyId: 'dfdghdsgfgdhg',
			secretAccessKey: 'dsdfdkgjhska'
		}
	});
}