// Engineer schema

//@ts-check
import { model, Schema } from 'mongoose';

import { IUser, RegisterDto } from './user.interface';
import { GenerateISODate } from '../util/date-time';

const userShema: Schema<IUser> = new Schema({
	firstName: { type: String, required: true, minLength: 3, lowercase: true, trim: true },
	surName: { type: String, required: true, minLength: 3, lowercase: true, trim: true },
	email: { type: String, required: true, lowercase: true, trim: true },
	isVerified: { type: Boolean, required: true, default: false },
	registrationToken: { type: String, required: true },
	registeredDate: { type: String, required: true, default: GenerateISODate },
	password: { type: String, required: true, trim: true },
});


export const User = model<IUser>('User', userShema);

const users: any[] = [
	{ id: '1', name: 'John Doe', email: 'john.doe@example.com', role: 'admin' },
	{ id: '2', name: 'Jane Doe', email: 'jane.doe@example.com', role: 'user' },
];

export const resolvers = {
	Query: {
		getUsers: () => users,
		getPerson: (_parent: any, { id }: { id: string; }) => {
			return users.find((person) => person.id === id);
		},
	},
	Mutation: {
		addUser: (_parent: any, { input }: { input: RegisterDto }): IUser => {
			const id = String(users.length + 1);
			const user = { id, ...input } as IUser;
			users.push(user);
			return user;
		},
	},
};
