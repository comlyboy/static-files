import mongoose from "mongoose";

export async function ConnectDB() {
	try {
		await mongoose.connect('mongodb://fdsg');
		console.log("Connected to database ==> 100%");
	} catch (error) {
		console.log(error);
		console.log("Cannot connect to database");

	}

}
